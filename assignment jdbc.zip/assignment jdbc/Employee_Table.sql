select *from Employee;
insert into Employee values(3,"Lok","Faculty");